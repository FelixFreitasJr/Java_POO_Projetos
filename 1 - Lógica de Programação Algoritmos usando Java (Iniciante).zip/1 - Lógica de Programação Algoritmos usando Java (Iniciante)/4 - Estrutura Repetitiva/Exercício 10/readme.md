<div>
  <h2>
    Fazer um programa para ler um número inteiro positivo N. O programa deve então mostrar na tela N linhas,
começando de 1 até N. Para cada linha, mostrar o número da linha, depois o quadrado e o cubo do valor, conforme
exemplo.
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              5<br>
              <br>
              <br>
              <br>
              <br>
            </td>
            <td>
              1 1 1<br>
              2 4 8<br>
              3 9 27<br>
              4 16 64<br>
              5 25 125<br>
</td>
        </tr>
    </table>
    </div>
