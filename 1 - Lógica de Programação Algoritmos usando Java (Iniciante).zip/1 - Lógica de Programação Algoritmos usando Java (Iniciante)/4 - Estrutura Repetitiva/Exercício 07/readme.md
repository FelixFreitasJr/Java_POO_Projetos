<div>
  <h2>
    Fazer um programa para ler um número N. Depois leia N pares de números e mostre a divisão do primeiro pelo
segundo. Se o denominador for igual a zero, mostrar a mensagem "divisao impossivel".
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              3<br>
              3 -2<br>
              -8 0<br>
              0 8<br>
            </td>
            <td>
              -1.5<br>
              divisao impossivel<br>
              0.0<br>
              <br>
</td>
        </tr>
    </table>
    </div>
