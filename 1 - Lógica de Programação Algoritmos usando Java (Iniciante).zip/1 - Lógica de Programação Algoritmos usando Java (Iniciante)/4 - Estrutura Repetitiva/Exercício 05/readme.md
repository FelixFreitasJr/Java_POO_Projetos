<div>
  <h2>
    Leia um valor inteiro N. Este valor será a quantidade de valores inteiros X que serão lidos em seguida.
Mostre quantos destes valores X estão dentro do intervalo [10,20] e quantos estão fora do intervalo, mostrando
essas informações conforme exemplo (use a palavra "in" para dentro do intervalo, e "out" para fora do intervalo).
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              5<br>
              14<br>
              123<br>
              10<br>
              -25<br>
              32<br>
            </td>
            <td>
              2 in<br>
              3 out<br>
              <br>
              <br>
              <br>
              <br>
</td>
        </tr>
    </table>
    </div>
