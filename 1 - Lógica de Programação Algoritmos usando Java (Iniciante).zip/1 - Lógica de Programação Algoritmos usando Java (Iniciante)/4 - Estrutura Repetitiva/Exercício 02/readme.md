<div>
  <h2>
    Escreva um programa para ler as coordenadas (X,Y) de uma quantidade indeterminada de pontos no sistema cartesiano. Para cada ponto escrever o quadrante a que ele pertence. O algoritmo será encerrado quando pelo menos uma de duas coordenadas for NULA (nesta situação sem escrever mensagem alguma).
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              2 2<br>
              3 -2<br>
              -8 -1<br>
              -7 1<br>
              0 2<br>
            </td>
            <td>
              primeiro<br>
              quarto<br>
              terceiro<br>
              segundo<br><br>
</td>
        </tr>
    </table>
    </div>
