<div>
  <h2>
    Leia um valor inteiro X (1 <= X <= 1000). Em seguida mostre os ímpares de 1 até X, um valor por linha, inclusive o
X, se for o caso.
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              8<br>
              <br>
              <br>
              <br>
            </td>
            <td>
              1<br>
              3<br>
              5<br>
              7
</td>
        </tr>
    </table>
    </div>
