### Atenção! Esses exercícios são:
- While
- for
