<div>
  <h2>
    Leia 1 valor inteiro N, que representa o número de casos de teste que vem a seguir. Cada caso de teste consiste
de 3 valores reais, cada um deles com uma casa decimal. Apresente a média ponderada para cada um destes
conjuntos de 3 valores, sendo que o primeiro valor tem peso 2, o segundo valor tem peso 3 e o terceiro valor tem
peso 5.
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              3<br>
              6.5 4.3 6.2<br>
              5.1 4.2 8.1<br>
              8.0 9.0 10.0<br>
            </td>
            <td>
              5.7<br>
              6.3<br>
              9.3<br>
              <br>
</td>
        </tr>
    </table>
    </div>
