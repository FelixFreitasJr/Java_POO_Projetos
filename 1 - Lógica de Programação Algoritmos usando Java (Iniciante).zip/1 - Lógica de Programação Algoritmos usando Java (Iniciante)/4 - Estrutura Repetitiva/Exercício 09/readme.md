<div>
  <h2>
    Ler um número inteiro N e calcular todos os seus divisores.
  </h2>
 
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              6<br>
              <br>
              <br>
              <br>
            </td>
            <td>
              1<br>
              2<br>
              3<br>
              6<br>
</td>
        </tr>
    </table>
    </div>
