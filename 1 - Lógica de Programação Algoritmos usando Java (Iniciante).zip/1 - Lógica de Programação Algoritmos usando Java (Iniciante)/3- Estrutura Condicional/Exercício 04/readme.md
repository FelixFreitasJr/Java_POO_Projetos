<div>
  <h2>
    Leia a hora inicial e a hora final de um jogo. A seguir calcule a duração do jogo, sabendo que o mesmo pode começar em um dia e terminar em outro, tendo uma duração mínima de 1 hora e máxima de 24 horas.
  </h2>
  
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>16 2</td>
            <td>O JOGO DUROU 10 HORA(S)</td>
        </tr>
        <tr>
            <td>0 0</td>
            <td>O JOGO DUROU 24 HORA(S)</td>
        </tr>
        <tr>
            <td>2 16</td>
            <td>O JOGO DUROU 14 HORA(S)</td>
        </tr>
    </table>
    </div>
