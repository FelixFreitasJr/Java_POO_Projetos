<div>
  <h2>
    Você deve fazer um programa que leia um valor qualquer e apresente uma mensagem dizendo em qual dos seguintes intervalos ([0,25], (25,50], (50,75], (75,100]) este valor se encontra. Obviamente se o valor não estiver em nenhum destes intervalos, deverá ser impressa a mensagem “Fora de intervalo”.
  </h2>
  
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>25.01</td>
            <td>Intervalo (25,50]</td>
        </tr>
        <tr>
            <td>25.00</td>
            <td>Intervalo [0,25]</td>
        </tr>
        <tr>
            <td>100.00</td>
            <td>Intervalo (75,100]</td>
        </tr>
       <tr>
            <td>-25.02</td>
            <td>Fora de intervalo</td>
        </tr>
    </table>
    </div>
