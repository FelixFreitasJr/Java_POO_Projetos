<div>
  <h2>
    Fazer um programa para ler um número inteiro, e depois dizer se este número é negativo ou não
  </h2>
  
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>-10</td>
            <td>NEGATIVO</td>
        </tr>
        <tr>
            <td>8</td>
            <td>NAO NEGATIVO</td>
        </tr>
        <tr>
            <td>00</td>
            <td>NAO NEGATIVO</td>
        </tr>
    </table>
    </div>
