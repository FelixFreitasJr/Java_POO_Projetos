<div>
  <h2>
    Leia 2 valores inteiros (A e B). Após, o programa deve mostrar uma mensagem "Sao Multiplos" ou "Nao sao Multiplos", indicando se os valores lidos são múltiplos entre si. Atenção: os números devem poder ser digitados em ordem crescente ou decrescente.
  </h2>
  
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>6 24</td>
            <td>Sao Multiplos</td>
        </tr>
        <tr>
            <td>6 25</td>
            <td>Nao sao Multiplos</td>
        </tr>
        <tr>
            <td>24 6</td>
            <td>Sao Multiplos</td>
        </tr>
    </table>
    </div>
