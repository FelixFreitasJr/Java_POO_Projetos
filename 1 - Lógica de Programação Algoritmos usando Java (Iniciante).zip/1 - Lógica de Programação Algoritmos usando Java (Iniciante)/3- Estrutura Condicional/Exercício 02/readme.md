<div>
  <h2>
    Fazer um programa para ler um número inteiro e dizer se este número é par ou ímpar.
  </h2>
  
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>12</td>
            <td>PAR</td>
        </tr>
        <tr>
            <td>-27</td>
            <td>IMPAR</td>
        </tr>
        <tr>
            <td>0</td>
            <td>PAR</td>
        </tr>
    </table>
    </div>
