<div>
  <h2>
    Fazer um programa que leia três valores com ponto flutuante de dupla precisão: A, B e C. Em seguida, calcule e mostre:
  </h2>
  
  <p>
    a) a área do triângulo retângulo que tem A por base e C por altura.<br>
    b) a área do círculo de raio C. (pi = 3.14159)<br>
    c) a área do trapézio que tem A e B por bases e C por altura.<br>
    d) a área do quadrado que tem lado B.<br>
    e) a área do retângulo que tem lados A e B.<br>
  </p>
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>3.0 4.0 5.2</td>
            <td>
              TRIANGULO: 7.800<br>
              CIRCULO: 84.949<br>
              TRAPEZIO: 18.200<br>
              QUADRADO: 16.000<br>
              RETANGULO: 12.000<br>
            </td>
        </tr>
        <tr>
            <td>12.7 10.4 15.2</td>
            <td>
              TRIANGULO: 96.520<br>
              CIRCULO: 725.833<br>
              TRAPEZIO: 175.560<br>
              QUADRADO: 108.160<br>
              RETANGULO: 132.080<br>
            </td>
        </tr>
    </table>
    </div>
