# Faça um programa para ler dois valores inteiros, e depois mostrar na tela a soma desses números com uma mensagem explicativa, conforme exemplos.

<div>
  <h2>Exemplos de Soma</h1>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>10<br>30</td>
            <td>SOMA = 40</td>
        </tr>
        <tr>
            <td>-30<br>10</td>
            <td>SOMA = -20</td>
        </tr>
        <tr>
            <td>0<br>0</td>
            <td>SOMA = 0</td>
        </tr>
    </table>
    </div>
