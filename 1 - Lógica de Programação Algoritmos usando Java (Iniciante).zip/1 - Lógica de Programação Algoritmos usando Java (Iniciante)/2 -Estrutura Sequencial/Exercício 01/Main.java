import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.Scanner.*;

class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int A, B, soma;

        A = sc.nextInt();
        B = sc.nextInt();

        soma = A + B;
        
        System.out.println("SOMA = " + soma);

        sc.close();
    }
}
