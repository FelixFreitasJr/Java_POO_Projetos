
<div>
  <h2>
    Faça um programa para ler o valor do raio de um círculo, e depois mostrar o valor da área deste círculo com quatro casas decimais conforme exemplos.
  </h2>
  
  <p>
    Fórmula da área: area = π . raio2 <br>Considere o valor de π = 3.14159
  </p>
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>2.00</td>
            <td>A=12.5664</td>
        </tr>
        <tr>
            <td>100.64</td>
            <td>A=31819.3103</td>
        </tr>
        <tr>
            <td>150.00</td>
            <td>A=70685.7750</td>
        </tr>
    </table>
    </div>
