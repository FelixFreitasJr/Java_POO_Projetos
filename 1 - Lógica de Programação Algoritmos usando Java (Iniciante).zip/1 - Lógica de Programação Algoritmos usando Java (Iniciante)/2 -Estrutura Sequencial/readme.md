### Atenção! Esses exercícios são:
- entrada, processamento, saída
