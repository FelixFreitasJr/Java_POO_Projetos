<div>
  <h2>
   Fazer um programa que leia o número de um funcionário, seu número de horas trabalhadas, o valor que recebe por hora e calcula o salário desse funcionário. A seguir, mostre o número e o salário do funcionário, com duas casas decimais.
  </h2>
  <!--
  <p>
    Fórmula da área: area = π . raio2 <br>Considere o valor de π = 3.14159
  </p> -->
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>
              25<br>
              100<br>
              5.50</td>
            <td>
              NUMBER = 25 <br> 
              SALARY = U$ 550.00</td>
        </tr>
        <tr>
            <td>
              1<br>
              200<br>
              20.50</td>
            <td>
              NUMBER = 1 <br> 
              SALARY = U$  4100.00</td>
        </tr>
        <tr>
            <td>
              6<br>
              145<br>
              15.55</td>
            <td>
              NUMBER = 6 <br> 
              SALARY = U$ 2254.75
            </td>
        </tr>
    </table>
    </div>
