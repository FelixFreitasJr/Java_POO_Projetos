<div>
  <h2>
    Fazer um programa para ler quatro valores inteiros A, B, C e D. A seguir, calcule e mostre a diferença do produto de A e B pelo produto de C e D segundo a fórmula: DIFERENCA = (A * B - C * D).
  </h2>
  <!--
  <p>
    Fórmula da área: area = π . raio2 <br>Considere o valor de π = 3.14159
  </p> -->
  
  <h3>Exemplos</h3>
    <table>
        <tr>
            <th>Entrada</th>
            <th>Saída</th>
        </tr>
        <tr>
            <td>5<br>6<br>7<br>8</td>
            <td>DIFERENCA = -26</td>
        </tr>
        <tr>
            <td>5<br>6<br>-7<br>8</td>
            <td>DIFERENCA = 86</td>
        </tr>
    </table>
    </div>
